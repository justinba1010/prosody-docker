-- Prosody IM
-- Copyright (C) 2008-2010 Matthew Wild
-- Copyright (C) 2008-2010 Waqas Hussain
--
-- This project is MIT/X11 licensed. Please see the
-- COPYING file in the source package for more information.
--



local unpack = table.unpack or unpack; --luacheck: ignore 113 143
local t_insert = table.insert;
function _G.import(module, ...)
	local m = package.loaded[module] or require(module);
	if type(m) == "table" and ... then
		local ret = {};
		for _, f in ipairs{...} do
			t_insert(ret, m[f]);
		end
		return unpack(ret);
	end
	return m;
end
